

export  interface  Student{
    id:number;
    uname:string;
    password:string;
    dob:Date;
    gender:string;
    email:string;
    phone:number;
    course:string;
    status:string;



}